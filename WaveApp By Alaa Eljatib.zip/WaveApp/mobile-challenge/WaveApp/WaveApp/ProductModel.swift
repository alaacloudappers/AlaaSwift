//
//  ProductModel.swift
//  WaveApp
//
//  Created by Alaa Alkhatib on 3/14/16.
//  Copyright © 2016 Alaa Alkhatib. All rights reserved.
//

import Foundation
class ProductModel {
    
    //MARK: VARIABLES
    var productApiResponseDelegate : ProductApiResponseDelegate?

    let business_id = "89746d57-c25f-4cec-9c63-34d7780b044b"
    
    let access_token = "bbVYINE16A1SUWQdTFT0bAUpPrAzIT"
    
    //METHODS
     func retrieveProductArray()
    {
        var productArray : [Product] = []
        
        let url = NSURL(string: "https://api.waveapps.com/businesses/\(business_id)/products/?access_token=\(access_token)")
        let task = NSURLSession.sharedSession().dataTaskWithURL(url!, completionHandler: { (data, response, error) -> Void in
            if let _ = data
            {
                do {
                    let jsonData = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers) as! NSArray
                    print(jsonData)
                    for jsonItem in jsonData
                    {
                    productArray.append(Product.parseProductItem(jsonItem as! NSDictionary as! [String : AnyObject]))
                    }
                    self.productApiResponseDelegate?.onProductApiResquestSuccess(productArray)
                } catch
                {
                    self.productApiResponseDelegate?.onProductApiResquestFailure(
                    "error in retreiving the data")
                }
            }
       
        })
     task.resume()
        
        
    }
    
}
