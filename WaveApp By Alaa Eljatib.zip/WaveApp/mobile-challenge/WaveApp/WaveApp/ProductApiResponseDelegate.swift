//
//  ProductApiResponseDelegate.swift
//  WaveApp
//
//  Created by Alaa Alkhatib on 3/14/16.
//  Copyright © 2016 Alaa Alkhatib. All rights reserved.
//

import Foundation

protocol ProductApiResponseDelegate
{
    func onProductApiResquestSuccess(productArr : [Product])
    func onProductApiResquestFailure(error: String)
    
}