//
//  Product.swift
//  WaveApp
//
//  Created by Alaa Alkhatib on 3/14/16.
//  Copyright © 2016 Alaa Alkhatib. All rights reserved.
//

import Foundation

class Product
{
    /*
    "id": 1,
    "url": "https://api.waveapps.com/businesses/c2731e5c-5001-4fe3-87ae-477f9a48dfcc/products/1/",
    "name": "Erlenmeyer flask",
    "price": 17.0,
    "description": "The Erlenmeyer flask is the most common flask in the DVHS chemistry lab. It is used to contain reaction solutions.",
    "is_sold": true,
    "is_bought": false,
    "income_account": {
    "id": 10,
    "url": "https://api.waveapps.com/businesses/c2731e5c-5001-4fe3-87ae-477f9a48dfcc/accounts/10/",
    },
    */
    //MARK: Properties
    var name : String = ""
    var price : Float = 0.0
    
    //MARK: Methods
    
    class func parseProductItem (responseItem: [String:AnyObject] ) -> Product
    {
        let product : Product = Product()
        
        //parsing
        
        //1- Name
        if  let x: AnyObject = responseItem["name"]
        {
            product.name = (x as? String)!
        }
        //2- Price
        if  let y: AnyObject = responseItem["price"]
        {
            product.price = (y as! Float)
        }
        
        return product
    }
}
