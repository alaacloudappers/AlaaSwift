//
//  ProductTableViewCell.swift
//  WaveApp
//
//  Created by Alaa Alkhatib on 3/14/16.
//  Copyright © 2016 Alaa Alkhatib. All rights reserved.
//

import UIKit

class ProductTableViewCell: UITableViewCell {

    @IBOutlet var productName: UILabel!
    
    
    @IBOutlet var productPrice: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
