//
//  ViewController.swift
//  WaveApp
//
//  Created by Alaa Alkhatib on 3/14/16.
//  Copyright © 2016 Alaa Alkhatib. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITableViewDataSource, UITableViewDelegate , ProductApiResponseDelegate{
    
//MARK: Outlets
    @IBOutlet var productsTableView: UITableView!
    
//MARK: Variables
   var productsArray : [Product] = []
    var productModel = ProductModel()
  
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.productsTableView.delegate = self
        self.productsTableView.dataSource = self
//        self.productsTableView.registerClass(ProductTableViewCell.self, forCellReuseIdentifier: "productCell")
        productModel.productApiResponseDelegate = self
            self.productModel.retrieveProductArray()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
       if let cell = productsTableView.dequeueReusableCellWithIdentifier("productCell") as! ProductTableViewCell!
       {
        cell.productName.text = self.productsArray[indexPath.section].name
        cell.productPrice.text = "\(self.productsArray[indexPath.section].price) $"
        return cell
        }
        return ProductTableViewCell()
        
    }
    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 3
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return self.productsArray.count
    }
    func onProductApiResquestFailure(error: String) {
        let alert = UIAlertController(title: "Connection Error", message: "There is a problem connecting with Wave products Server , Make sure you're connected to the Internet", preferredStyle: UIAlertControllerStyle.Alert)
        let action = UIAlertAction(title: "Retry", style: UIAlertActionStyle.Cancel) { (UIAlertAction) -> Void in
            self.productModel.retrieveProductArray()
        }
        alert.addAction(action)
        self.performSegueWithIdentifier("alert", sender: self)

    }
    
    
    func onProductApiResquestSuccess(productArr: [Product]) {
        self.productsArray = productArr
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
        self.productsTableView.reloadData()    
        })
        
    }

}

